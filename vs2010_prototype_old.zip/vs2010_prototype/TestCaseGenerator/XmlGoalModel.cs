﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestCaseGenerator
{
    class XmlGoalModel
    {
        public XmlGoalModel()
        {
        }

        public string[] listAllGoals()
        {
            return null;
        }


    }
}
